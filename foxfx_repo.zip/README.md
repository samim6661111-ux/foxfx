# foxfx
Actions tab -> train-foxfx -> Run workflow. Download "foxfx-output" artifact when done.
Only your own recordings go in shots/.
